# utad-spark-ml-setup
Información para arrancar el curso utad-spark-ml y los ejercicios.
