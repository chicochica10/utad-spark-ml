# utad-spark-ml-setup
fichero vagrant del curso ml de la UTAD y los notebooks de ejercicios.
